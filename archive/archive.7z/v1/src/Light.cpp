#include <Arduino.h>
#include "Light.h"

void Light::begin()
{
    
}